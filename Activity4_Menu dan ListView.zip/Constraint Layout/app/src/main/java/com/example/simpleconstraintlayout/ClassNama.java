package com.example.simpleconstraintlayout;

public class ClassNama {
    private String Nama;

    //inisialisasi objek
    public ClassNama(String nama) {
        this.Nama = nama;
    }

    //Membuat method getName untuk mengembalikan nilai ke variabel Nama
    public String getName()
    {
        return this.Nama;
    }
}
